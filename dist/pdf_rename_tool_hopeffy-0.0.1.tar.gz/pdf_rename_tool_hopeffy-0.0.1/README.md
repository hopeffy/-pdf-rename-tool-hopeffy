# PDF Title Renamer

A simple Python utility to automatically rename PDF files based on the title found on their first page.

## Installation

```bash
pip install pdf-title-renamer
```

## Usage

Navigate to the directory containing your PDF files and run the following command:

```bash
pdf-rename
```

The script will scan all PDF files in the current directory, identify their titles, and rename them accordingly.

**Note:** This is a placeholder README. You can update it with more details.
